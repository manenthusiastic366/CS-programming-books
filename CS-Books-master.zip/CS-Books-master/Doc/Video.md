## <h1 align="center">1、优质编程学习视频</h1>

我在学习计算机八九年的时间里基本**都是通过视频和书籍自学**的，其中令我大呼过瘾的计算机经典视频实在是太多了。

在我学习计算机的过程中，看过很多不错的计算机视频，比如：比如**C/C++、Java、Go语言、Python、操作系统、数据结构和算法、计算机网络、数据库、Python爬虫、机器学习**等。

前段时间花了一些时间专门去总结了一下自己的学习视频，一共分为三期，可以免费白嫖的那种！

<img src="http://oss.interviewguide.cn/img/202203261421142.png" alt="第一期" style="width:400px;" />

<img src="http://oss.interviewguide.cn/img/202203261421279.png" alt="第二期" style="width:400px;" />

<img src="http://oss.interviewguide.cn/img/202203261422715.png" alt="第三期" style="width:400px;"  />

## 免费获取方式

扫描下方二维码，回复关键字” **学习路线**“，即可获取我精心总结的学习路线和配套资源

<img src="http://oss.interviewguide.cn/img/202203261416899.png" style="width:200px" />



## <h1 style="align:center">2、各种学习路线</h1>

**计算机网络学习路线**：[点击查看全文](https://mp.weixin.qq.com/s?__biz=Mzg2MDU0ODM3MA==&mid=2247501298&idx=1&sn=5fc050d0a35c53e810823828f04a8e1c&chksm=ce26398ff951b099d3216a7cf5bae003aaf089501bfc8b4553c4c07f2239bd1c4a95473ecc7c&scene=178&cur_album_id=1857548892041478149#rd)

![计算机网络](http://oss.interviewguide.cn/img/202203261506718.png)

**C++学习路线**：[点击查看全文](https://mp.weixin.qq.com/s/3pcENm2--dVWksNjvtCTcQ)

<img src="http://oss.interviewguide.cn/img/202203261423316.png" alt="C++学习路线" style="zoom:33%;" />



**Golang学习路线**：[点击查看全文](https://mp.weixin.qq.com/s/HkIKYaQfgI9_1o6o7LbGVg)

<img src="http://oss.interviewguide.cn/img/202203261423317.png" alt="Golang学习路线" style="zoom:20%;" />

**前端学习路线**：

以及还有其余的学习路线等，正在努力更文中~

## 免费获取方式

扫描下方二维码，回复关键字” **学习路线**“，即可获取我精心总结的学习路线和配套资源

<img src="http://oss.interviewguide.cn/img/202203261416899.png" style="width:200px" />

