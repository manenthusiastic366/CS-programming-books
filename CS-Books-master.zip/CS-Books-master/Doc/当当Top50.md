<h1 align="center">计算机经典图书Top50&互联网一二线中厂校招面试PDF合集</h1>

## 1、互联网一二线中厂校招面试PDF合集

<img  src="http://oss.interviewguide.cn/img/202211242037481.png" align="middle" style="zoom:50%;"  />
     <img  src="http://oss.interviewguide.cn/img/202211242037190.png" align="middle" style="zoom:50%;"  />
  <img  src="http://oss.interviewguide.cn/img/202211242037292.png" align="middle" style="zoom:50%;"  />





### 下载方式

扫描下方二维码，回复关键字”**面经合集**“，即可获取最新互联网校招面经合集！

<div align="center">
 <img src="http://oss.interviewguide.cn/img/202310061834557.jpg" style="zoom:50%;" />
</div>



## 2、计算机经典图书Top50

偶然间在当当图书榜看到了一份计算机经典图书Top50榜单，由于这份榜单中很多图书都是珍贵书籍，我已经尽力收集了相应的PDF电子版，现在免费分享给大家！

**下载方式在文末**

<img src="http://oss.interviewguide.cn/img/202203261420890.png" alt="当前页面中的书籍全部收录好了" style="zoom:50%;" />

### 一、C/C++

- 《C++ Primer Plus》
- 《C++ Primer(第五版)带书签 高清完整版》
- 《C++ Primer 习题集》
- 《C++ Primer 5th 英文版》
- 《C++ Primer-第4版》
- 《C++ Templates》
- 《STL源码剖析 + 源码》
- 《C++编程调试秘笈》
- 《侯捷STL课件》
- 《深度探索C++对象模型》
- 《深入理解C++11》
- 《提高C++性能的编程技术.左飞》
- 《Effective-C++-第二版》
- 《深入理解C++11新特性解析与应用》
- 《Effective C++ 第三版 高清PDF》
- 《Effective STL中文版》
- 《C++ 编程规范-101条规则准则与最佳实践》
- 《C++编程思想（两卷合订本）》
- 《C++并发编程实战》
- 《C++沉思录中文第二版》
- 《C++程序设计语言》

### 二、 Java

- 《Effective Java 中文第二版》
- 《Java性能优化权威指南》
- 《Java核心技术(卷1）第8版》
- 《Java核心技术(卷2）第8版》
- 《Head First Java第二版涵盖java5.0》
- 《Java 8 实战》

###  三、Python

- 《编程小白的第一本Python入门书》
- 《笨办法学Python（第三版）》
- 《可爱的Python插图版_文字版》
- 《A Byte of Python3(中文版)》
- 《Python编程：从入门到实践》

### 四、数据结构与算法

- 《算法 4》
- 《计算机程序设计艺术卷1：基本算法》
- 《计算机程序设计艺术卷2：半数值算法》
- 《计算机程序设计艺术卷3：排序与查找》
- 《算法设计手册》
- 《编程珠玑》
- 《剑指Offer：名企面试官精讲典型编程》
- 《算法谜题》
- 《算法图解》
- 《挑战程序设计竞赛(第1版)》
- 《挑战程序设计竞赛(第2版)》

### 五、操作系统

- 《深入理解计算机系统 第3版》
- 《现代操作系统、英文版》
- 《现代操作系统（第三版）中文版》
- 《30天自制操作系统 (图灵程序设计丛书)》
- 《操作系统设计与实现》

### 六、计算机网络

- 《计算机网络-自顶向下方法》
- 《网络是怎样连接的》
- 《图解 HTTP》
- 《图解TCP/IP》
- 《TCP/IP详解 卷1：协议》
- 《计算机网络与因特网》
- 《tcp源码分析》
- 《HTTP 权威指南》
- 《wireshark 数据包分析实战》
- 《wireshark 网络分析就是这么简单》
- 《Wireshark网络分析实战》

### 七、Liunx网络编程

- 《TCPIP网络编程》
- 《Unix网络编程》
- 《Unix环境高级编程》
- 《Linux高性能服务器编程》
- 《Linux多线程服务器端编程》

### 八、大杀器

- 《计算机程序的构造和解释》
- 《深入理解计算机系统》
- 《操作系统导论》
- 《算法导论》

### 下载方式

扫描下方二维码，回复关键字” **005**“，即可获取我精心收集的计算机经典图书Top50！

<div align="center">
 <img src="http://oss.interviewguide.cn/img/202310061834557.jpg" style="zoom:50%;" />
</div>
